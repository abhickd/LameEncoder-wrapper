//Wrapper to the lame library...
#include "lameWrapper.h"

#include <cstring>


lameWrapper::lameWrapper()
{
    lame_ = lame_init();
}

lameWrapper::~lameWrapper()
{
    lame_close( lame_ );
}

int lameWrapper::set_in_samplerate( int sample_rate )
{
    return lame_set_in_samplerate( lame_, sample_rate );
}

int lameWrapper::set_brate( int byte_rate )
{
    return lame_set_brate( lame_, byte_rate );
}

int lameWrapper::set_num_channels( int channels )
{
    return lame_set_num_channels( lame_, channels );
}

int lameWrapper::set_mode( MPEG_mode_e mode )
{
    return lame_set_mode( lame_, mode );
}

int lameWrapper::set_decode_only( int p )
{
    return lame_set_decode_only( lame_, p );
}

int lameWrapper::set_VBR( vbr_mode_e mode )
{
    return lame_set_VBR( lame_, mode );
}

int lameWrapper::init_params()
{
    return lame_init_params( lame_ );
}

int lameWrapper::encode_flush( unsigned char * mp3buf, int size )
{
    return lame_encode_flush( lame_, mp3buf, size );
}

int lameWrapper::set_quality( int num )
{
    return lame_set_quality( lame_, num  );
}

int lameWrapper::encode_buffer(
        const short int     buffer_l [],
        const short int     buffer_r [],
        const int           nsamples,
        unsigned char*      mp3buf,
        const int           mp3buf_size )
{
    return lame_encode_buffer( lame_, buffer_l, buffer_r, nsamples, mp3buf, mp3buf_size );
}

int lameWrapper::encode_buffer_interleaved(
        short int           pcm[],
        int                 num_samples,
        unsigned char*      mp3buf,
        int                 mp3buf_size )
{
    return lame_encode_buffer_interleaved( lame_, pcm, num_samples, mp3buf, mp3buf_size );
}

