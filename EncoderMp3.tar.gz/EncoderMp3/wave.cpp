
#include "wave.h"          

#include <stdexcept> 
#include <fstream> 
#include <errno.h> 
#include <cstring>

using namespace wave;

Wave::Wave( const std::string & filename ) throw( std::exception )
{
    fmt.wFormatTag      = 0;
    extra_param_length_ = 0;
    fact.samplesNumber  = -1;

    std::ifstream file( filename.c_str(), std::ios_base::binary | std::ios_base::in );
    if( file.is_open() == false )
    {
        throw std::runtime_error( strerror( errno ) );
    }

    file.read( reinterpret_cast<char*>( &riff ), RIFF_SIZE );
    file.read( reinterpret_cast<char*>( &fmthdr ), FMTHDR_SIZE );

    file.read( reinterpret_cast<char*>( &fmt ), FMT_SIZE );

    unsigned fmt_extra_bytes    = fmthdr.fmtSIZE - FMT_SIZE;

    if( fmt_extra_bytes > 0 )
    {
        fmt_extra_bytes_.resize( fmt_extra_bytes );

        file.read( & fmt_extra_bytes_[0], fmt_extra_bytes );
    }

    if( fmt.wFormatTag != 1 )
    {
        file.read( reinterpret_cast<char*>( &extra_param_length_ ), 2 ); //2 bytes
        if( extra_param_length_ > 0 )
        {
            extra_param_.resize( extra_param_length_ );
            file.read( & extra_param_[0], extra_param_length_ );
        }
    }

    file.read( reinterpret_cast<char*>( &data.dataID ), 4 );

    if( data.dataID[0] == 'f' && data.dataID[1] == 'a' && data.dataID[2] == 'c' && data.dataID[3] == 't' )
    {
        file.read( reinterpret_cast<char*>( &fact ), FACT_SIZE );
        file.read( reinterpret_cast<char*>( &data ), DATA_SIZE );
    }
    else
        file.read( reinterpret_cast<char*>( &data.dataSIZE ), 4 );

    wave_.resize( data.dataSIZE );

    file.read( & wave_[0], data.dataSIZE );
}

Wave::Wave()
{
    extra_param_length_ = 0;
    fmt.wFormatTag      = 0;
    fact.samplesNumber  = -1;
}

Wave::~Wave()
{
   // extra_param_length_ = 0;
}

int16_t Wave::get_channels() const
{
    return fmt.nChannels;
}

int32_t Wave::get_samples_per_sec() const
{
    return fmt.nSamplesPerSec;
}

int32_t Wave::get_avg_bytes_per_sec() const
{
    return fmt.nAvgBytesPerSec;
}

int32_t Wave::get_data_size() const
{
    return data.dataSIZE;
}

void Wave::get_samples( unsigned int offset, unsigned int size, std::vector<char> & samples ) const
{
    if( offset > ( unsigned )data.dataSIZE )
        return;

    unsigned int real_size = ( offset + size ) < ( unsigned )data.dataSIZE ? size : ( unsigned )data.dataSIZE - offset;

    samples.insert( samples.end(), & wave_[offset], & wave_[offset + real_size] );
}
