//Utility functions...

#include <dirent.h>
#include <vector>
#include<iostream>
#include<stdio.h>
#include <cstring>
#include<stdio.h>


bool hasEnding (std::string const &fullString, std::string const &ending);

void replaceExt(std::string& s, const std::string& newExt);





