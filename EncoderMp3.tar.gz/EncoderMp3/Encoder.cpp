//This file provides the encoder functionality...

#include "Encoder.h"  

using namespace std;
bool encode( const char *in_file, const char *out_file )
{
    wave::Wave pcm( in_file );
    unsigned sample_rate    = pcm.get_samples_per_sec();
    unsigned byte_rate      = pcm.get_avg_bytes_per_sec();
    unsigned channels       = pcm.get_channels();

    std::ofstream mp3( out_file, std::ios_base::binary | std::ios_base::out  );

    const int PCM_SIZE = 8192;
    const int MP3_SIZE = 8192;

    unsigned offset = 0;

    std::vector<char> pcm_buffer;
    pcm_buffer.reserve( sizeof(short int) * PCM_SIZE * 2 );

    unsigned char mp3_buffer[MP3_SIZE];

    lameWrapper l;

    l.set_in_samplerate( sample_rate );
    l.set_brate( byte_rate );

    if( channels == 1 )
    {
        l.set_num_channels( 1 );
        l.set_mode( MONO );
    }
    else
    {
        l.set_num_channels( channels );
    }

    l.set_VBR( vbr_default );
    l.set_quality(5);              //Good quality Encoding...
    l.init_params();

    while( true )
    {
        int k = ( channels == 1 ) ? 1 : 2;

        unsigned size = PCM_SIZE * k * sizeof( short int );

        pcm.get_samples( offset, size, pcm_buffer );

        unsigned read = pcm_buffer.size();

        offset += read;

        if( read > 0 )
        {
            unsigned read_shorts = read / 2;  // need number of 'short int' read

            int write = 0;

            if( channels == 1 )
            {
                write = l.encode_buffer( reinterpret_cast<short int*>( &pcm_buffer[0] ), NULL, read_shorts, mp3_buffer, MP3_SIZE );
            }
            else
            {
                write = l.encode_buffer_interleaved( reinterpret_cast<short int*>( &pcm_buffer[0] ), read_shorts, mp3_buffer, MP3_SIZE );
            }

            pcm_buffer.clear();

            mp3.write( reinterpret_cast<char*>( mp3_buffer ) , write );
        }

        if( read < size )
        {
            int write = l.encode_flush( mp3_buffer, MP3_SIZE );

            mp3.write( reinterpret_cast<char*>( mp3_buffer ), write );

            break;
        }

    };
    return true;
}


