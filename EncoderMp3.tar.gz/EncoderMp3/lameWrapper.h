//Wrapper to the lame library...
#include "lame.h"

class lameWrapper
{
public:
    lameWrapper();
    ~lameWrapper();

    int set_in_samplerate( int sample_rate );
    int set_brate( int byte_rate );

    int set_num_channels( int channels );
    int set_mode( MPEG_mode_e mode );

    int set_decode_only( int );

    int set_VBR( vbr_mode_e mode );
    int set_quality(int num);
    int init_params();
    int encode_flush( unsigned char * mp3buf, int size );
    int encode_buffer(
            const short int     buffer_l [],   /* PCM data for left channel     */
            const short int     buffer_r [],   /* PCM data for right channel    */
            const int           nsamples,      /* number of samples per channel */
            unsigned char*      mp3buf,        /* pointer to encoded MP3 stream */
            const int           mp3buf_size ); /* number of valid octets in this
                                                  stream                        */

    int encode_buffer_interleaved(
            short int           pcm[],         /* PCM data for left and right
                                                  channel, interleaved          */
            int                 num_samples,   /* number of samples per channel,
                                                  _not_ number of samples in
                                                  pcm[]                         */
            unsigned char*      mp3buf,        /* pointer to encoded MP3 stream */
            int                 mp3buf_size ); /* number of valid octets in this
                                                  stream                        */
private:
    lame_t  lame_;
};

class MP3Data
{
    friend class Hip;

public:
    MP3Data();

    bool is_header_parsed() const;
    int get_stereo() const;
    int get_samplerate() const;
    int get_bitrate() const;

private:
    mp3data_struct mp3data_;
};

