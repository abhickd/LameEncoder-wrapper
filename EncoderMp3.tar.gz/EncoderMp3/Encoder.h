
#include <fstream>                  // std::ofstream
#include <stdexcept>                // std::logic_error
#include "wave.h"           // Wave header
#include "lameWrapper.h"   // Lame include file
#include <vector>
#include<stdio.h>
#include <cstring>

bool encode( const char *in_file, const char *out_file );
