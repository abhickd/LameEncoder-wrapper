#include <iostream>
#include <cstdlib>
#include <pthread.h>
#include "Utils.h"
#include <dirent.h>
#include "Encoder.h"
#include <sys/sysinfo.h>

using namespace std;

int NumThreads;
std::string dirName;
std::vector<std::string> files;
int CreateThreads (int numFiles);
int processFiles(int threadId);

void *ThreadCreator(void *threadid) {
   long tid;
   tid = (long)threadid;
   cout << "Started Thread ID, " << tid << endl;
   processFiles(tid);
   pthread_exit(NULL);
}


int main(int argc, char* argv[])
{
	DIR *dir;
	std::vector<std::string>::iterator it;
	struct dirent *ent;

	if ( argc != 2 ) // argc should be 2 for correct execution
	{
		cout<<"usage: "<< argv[0] <<" <dirname>\n";
		return 0;
	}

	dirName = argv[1];


        //Read only wav file from the directory specified and push into vector.
	if ((dir = opendir (dirName.c_str())) != NULL) {
		while ((ent = readdir (dir)) != NULL) {
			if(hasEnding(ent->d_name,".wav"))
			{
				files.push_back(std::string(ent->d_name));
			}
		}
		closedir (dir);
	} else {
		printf("The directory does not exist\n");
		return 0;
	}
 
        if(files.size() == 0)
	{
 	    printf("No wav files exist\n");
            return 0;
	}

        if(files.size() > 1)
        {
	   CreateThreads(files.size());
        }
        else
	{
           //No need to create threads when there is only one file...
	   std::string	wavFilename = dirName + files[0];
	   std::string	mp3Filename = wavFilename;
	   replaceExt(mp3Filename,"mp3");
	   encode(wavFilename.c_str(), mp3Filename.c_str());
           printf("The wav Filename  =%s --->>> mp3Filename =%s\n",wavFilename.c_str(),mp3Filename.c_str());
	}
	return 0;
}


int processFiles(int threadId)
{
   std::string mp3Filename;
   std::string wavFilename;
   int count = files.size()/NumThreads;
   int remaining = files.size() % NumThreads;
   int numofFiles = 0;
  
   for(int i= (threadId * count); i< (threadId * count + count); i++)
   {
	   wavFilename = dirName + files[i];
	   mp3Filename = wavFilename;
	   replaceExt(mp3Filename,"mp3");
	   encode(wavFilename.c_str(), mp3Filename.c_str());
	   //printf("The wav Filename  =%s --->>> mp3Filename =%s converted on Core=%d\n",wavFilename.c_str(),mp3Filename.c_str(),threadId);
           numofFiles++;
   }

   if(threadId < remaining)
   {
	   wavFilename = dirName + files[(count * NumThreads)+threadId];
	   mp3Filename = wavFilename;
	   replaceExt(mp3Filename,"mp3");

	   encode(wavFilename.c_str(), mp3Filename.c_str());
	   //printf("The wav Filename  =%s --->>> mp3Filename =%s converted on Core=%d\n",wavFilename.c_str(),mp3Filename.c_str(),threadId);
           numofFiles++;
   }
	   printf("The num of files processed on Core %d =%d\n",threadId,numofFiles);
}

int CreateThreads (int numFiles) {
   //Create the number of threads equals to the number of cores...
   int NumCores = get_nprocs();
   int rc;
   int i;
   cpu_set_t cpuset;
   
   if(numFiles <  NumCores)
   {
     NumThreads = numFiles;
   }
   else
   {
     NumThreads = NumCores;
   }


   pthread_t threads[NumThreads];

   for( i = 0; i < NumThreads; i++ ) {
      cout << "main() : Creating thread, " << i << endl;
      rc = pthread_create(&threads[i], NULL, ThreadCreator, (void *)i);
     
      cout << "main() : Assigning to Core " << i << endl;
    CPU_ZERO(&cpuset);
    CPU_SET(i, &cpuset);
    int rc = pthread_setaffinity_np(threads[i],
                                    sizeof(cpu_set_t), &cpuset); 
      if (rc) {
         cout << "Error:unable to create thread," << rc << endl;
         exit(-1);
      }
   }
   pthread_exit(NULL);
}

